import React, { useState } from "react";
import Navbar from "./components/navbar/Navbar";
import Pages from "./components/navbar/pages/Pages";
import Footer from "./components/Footer";
function App() {
  let [cord, setCord] = useState({
    x: 0,
    y: 0
  })
  window.addEventListener('mousemove', (e) => {
    setCord({
      ...cord,
      x: e.x, y: e.y
    })
  })
  return (
    <>
      <div className="box" style={{ top: `${cord.y}px`, left: `${cord.x}px` }} ></div>
      <Navbar />
      <Pages />
      <Footer />
    </>
  );
}

export default App;
