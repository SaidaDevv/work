import React, { Component, useState } from 'react';
import '../components/navbar/Navbar.css'
import room from '../components/img/room.png';
import image1 from '../components/img/image 100.png';
import image2 from '../components/img/image 101.png';
import image3 from '../components/img/image 106.png';
import { Button } from '@mui/material';
import "slick-carousel/slick/slick.css"; 
import "slick-carousel/slick/slick-theme.css";
import Slider from "react-slick";
import mix1 from '../components/img/mix1.png';
import mix2 from '../components/img/mix8.png';
import mix3 from '../components/img/mix4.png';
import mix4 from '../components/img/mix3.png';
import mix5 from '../components/img/mix5.png';
import mix6 from '../components/img/mix6.png';
import mix7 from '../components/img/mix7.png';
import mix8 from '../components/img/mix8.png';
import mix9 from '../components/img/mix2.png';
import images1 from '../components/img/image 1.png';
import images3 from '../components/img/image 3.png';
import images4 from '../components/img/image 4.png';
import images5 from '../components/img/image 6.png';
import images6 from '../components/img/image 7.png';
import images7 from '../components/img/image 8.png';
import images8 from '../components/img/image 9.png';
import {AiFillLike,AiOutlineLike} from 'react-icons/ai'

function Home() {
  const [data, setData] = useState([
        { id: 1, rasm: images1, title: 'Syltherine', descrip: 'Stylish cafe chair', value: 'Rp 2.500.000',  like: false, },
        { id: 2, rasm: images3, title: 'Lolito', descrip: 'Luxury big sofa', value: 'Rp 7000.000',  like: false, },
        { id: 3, rasm: images4, title: 'Respira', descrip: 'Outdoor bar table and stool', value: 'Rp 500.000',  like: false, },
        { id: 4, rasm: images5, title: 'Grifo', descrip: 'Night lamp', value: 'Rp 1.500.000',  like: false, },
        { id: 5, rasm: images6, title: 'Muggo', descrip: 'Small mug', value: 'Rp 150.000',  like: false, },
        { id: 6, rasm: images7, title: 'Pingky', descrip: 'Cute bed set', value: 'Rp 7.000.000',  like: false, },
        { id: 7, rasm: images8, title: 'Potty', descrip: 'Minimalist flower pot', value: 'Rp 500.000',  like: false, },
        { id: 8, rasm: images1, title: 'Leviossa', descrip: 'Stylish cave pots', value: 'Rp 2.500.000',  like: false, },
      ]);


      const [cart, setCart] = useState([]);
      const [tableBollean, setTableBollean] = useState(true);
      const [inputValue, setInputValue] = useState({
        id:"",
        rasm: "",
        title:"",
        descrip:"",
        value:"",
        like: false,
        
      });


      const handleLike = (id) => {
        setData(
          data.map((item) =>
            item.id === id ? { ...item, like: !item.like } : item
          )
        );
      };
    
    
      
        const settings = {
          dots: true,
          infinite: true,
          autoplay: true,
          speed: 1900,
          autoplaySpeed: 1900,
          slidesToShow: 1,
          slidesToScroll: 1,
        }
    
  return (
    <div>
      
              <div className="page_imgside">
        <img src={room} alt="" className='room' />
        <div className="discover">
          <p className="little">New Arrival</p>
          <p className="big">Discover Our New Collection</p>
          <p className="lorem">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis.</p>
          <button className='buy'><p className="namebtn">BUY Now</p></button>
        </div>
      </div>

      <div className="browse">
        <p className="rangeTitle">Browse The Range</p>
        <p className="lorems">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
        <div className="simpleCards">
          <img src={image1} alt="" className='image1' />

          <img src={image2} alt="" className='image1' />

          <img src={image3} alt="" className='image1' />

        </div>
        <p className="words">
          <p className="dining">Dining</p>
          <p className="living">Living</p>
          <p className="Bedroom">Bedroom</p>
        </p>
      </div>

      <div className="mapPart">
        <p className="product">Our Products</p>
        <div className="carts">
          {data.map(item => (
            <>
            <div className='cartes' key={item.id}>
              <img className='mapimg' src={item.rasm} alt={item.title} />
              <h3 className='maptitle'>{item.title}</h3>
              <p className='mapdescrip'>{item.descrip}</p>
              <p className='mapvalue'>{item.value}</p>
            
            </div>

              


 </>

              
    
          ))}


<div className="container">
<button className='addCard'>Add Card</button> <br />
{
  data.map((elem,index)=>{
    return(
      <div>

<Button className='like' onClick={() => handleLike(elem.id)} color='error' variant='outlined'> {elem.like ? <AiFillLike /> : <AiOutlineLike />} Like</Button>
      </div>
    )
  })
}
</div>




        </div>

        <Button variant='outlined' color='warning' style={{ padding: '15px 40px', margin: '100px 550px' }}>Show More</Button>

      </div>

      <div className="carousel">
        <div className="carousel1">
          <div className="caroTitle">50+ Beautiful rooms
            inspiration</div>
          <div className="caroDes">Our designer already made a lot of beautiful prototipe of rooms that inspire you</div>
          <div className="buy" style={{
            padding: '27px 60px', color: 'white', marginTop: '20px',marginLeft:'-5px'}}>Explore More</div>
        </div>

        <div className="mainCarousel">


        <Slider className='slider' {...settings}>
          <div>
            <h3><img src={image1} alt="" /></h3>
          </div>
          <div>
            <h3><img src={image2} alt="" /></h3>
          </div>
          <div>
            <h3><img src={image3} alt="" /></h3>
          </div>
         
          
        
        </Slider>



        </div>


      </div>

<div className="mixType">
  <div className="mixSmall">Share your setup with</div>
  <div className="mixTitle">#FuniroFurniture</div>
  <div className="mixImg">
  <img src={mix1} className='mix1' alt="" />
  <img src={mix2} className='mix2' alt="" />
  <img src={mix3} className='mix3' alt="" />
  <img src={mix4} className='mix4' alt="" />
  <img src={mix5} className='mix5' alt="" />
  <img src={mix6} className='mix6' alt="" />
  <img src={mix7} className='mix7' alt="" />
  <img src={mix8} className='mix8' alt="" />
  <img src={mix9} className='mix9' alt="" />
  </div>
</div>
    </div>
  )
}

export default Home