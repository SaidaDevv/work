import React, { Component, useState } from 'react';
import '../navbar/Navbar.css';
import logo from '../img/logo.png';
import { BsPerson } from 'react-icons/bs';
import { FiSearch } from 'react-icons/fi';
import { FcLikePlaceholder } from 'react-icons/fc';
import { SlBasket } from 'react-icons/sl';
import "slick-carousel/slick/slick.css"; 
import "slick-carousel/slick/slick-theme.css";
import { Link } from 'react-router-dom';




function Navbar() {

 

  return (

    <div>




      <div className="navbar">
        <img src={logo} alt="" className='logo' />
        <p className='Furniro'>Furniro</p>

        <p className="divs">
          <p className='pages1'><Link className='you' to={'/'}>Home</Link></p>
          <p className='pages1'><Link className='you' to={'/shop'}>Shop</Link></p>
          <p className='pages1'><Link className='you' to={'/about'}>About</Link></p>
          <p className='pages1'><Link className='you' to={'/contact'}>Contact</Link></p>
          <button className='btn1'><BsPerson /></button>
          <button className='btn1'><FiSearch /></button>
          <button className='btn1'><FcLikePlaceholder />{data.filter((elem) => elem.like === true).length}</button>
          <button className='btn1'><SlBasket /></button>

        </p>
      </div>








    </div>
  )
}

export default Navbar;