import React from 'react'
import { Route, Routes } from 'react-router'
import Home from '../../Home'
import Shop from '../../Shop'
import About from '../../About'
import Contact from '../../Contact'

function Pages() {
  return (
    <div>
        <Routes>
            <Route path='/' element={<Home/>}></Route>
            <Route path='/shop' element={<Shop/>}></Route>
            <Route path='/about' element={<About/>}></Route>
            <Route path='/contact' element={<Contact/>}></Route>
        </Routes>
    </div>
  )
}

export default Pages