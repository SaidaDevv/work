import React from 'react'
import '../components/navbar/Navbar.css'
import { Link } from 'react-router-dom'

function Footer() {
    return (
        <div className='footer'>
           <div className="p"> <p className='Furniro'>Furniro.</p>
            <p className='univer'>400 University Drive Suite 200 Coral Gables,
                FL 33134 USA</p>

            <p className='year'>2023 furino. All rights reverved</p>
            </div>


<div className="links">
    <p className="link">Links</p>
    <p className="home"><Link className='you' to={'/'}>Home</Link></p>
    <p className="shop"><Link className='you' to={'/shop'}>Shop</Link></p>
    <p className="about"><Link className='you' to={'/about'}>About</Link></p>
    <p className="contact"><Link className='you' to={'/contact'}>Contact</Link></p>
</div>

<div className="linkss">
    <p className="link">Help</p>
    <p className="home">Payment Options</p>
    <p className="shop">Returns</p>
    <p className="about">Privacy Policies</p>

</div>





        </div>
    )
}

export default Footer