import React from 'react'
import sort from '../components/img/Rectangle 1.png'
import '../components/navbar/Navbar.css'
import { Input, Stack } from '@mui/material'
import icon1 from '../components/img/icon1.svg'
import icon2 from '../components/img/icon2.svg'
import icon3 from '../components/img/Vector.svg'


function Contact() {
  return (
    <div>
      <img src={sort} alt="" className="shopimg" />
      <p className="shoptitle">Contact</p>
      <div className="smth">
        <p className="get">Get In Touch With Us</p>
        <p className="information">For More Information About Our Product & Services. Please Feel Free To Drop Us An Email. Our Staff Always Be There To Help You Out. Do Not Hesitate!</p>
        <div className="inputs">
          <div className="malumotlar">
            <div className="add">
              <div className="icon1"><img src={icon3} alt="" /></div>
              <div> <div className="address">Address</div>
                <div className="adressType">236 5th SE Avenue, New York NY10000, United States</div></div>
            </div>
            <div className="phone">
              <img src={icon2} alt="" />
              <div className="pteg"> <p className="tel">Phone</p>
                <p className="des">Mobile: +(84) 546-6789
                  Hotline: +(84) 456-6789</p></div>
            </div>
            <div className="time">
              <img src={icon1} alt="" />
              <div className="phones">Working Time</div>
              <div className="des">Monday-Friday: 9:00 - 22:00
                Saturday-Sunday: 9:00 - 21:00</div>
            </div>
          </div>
          <div className="submitPart">
            <Stack className='stack' spacing={2}>
              <Input className='sm1' size="sm" placeholder="Abc" />
              <Input className='sm2' size="sm" placeholder="Abc@def.com" />
              <Input className='sm3' size="sm" placeholder="this is an optional" />
              <Input className='sm4' size="sm" placeholder="Hi I'd like to ask about" />
            </Stack>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Contact