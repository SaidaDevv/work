import React, { useEffect, useState } from 'react';
import '../components/navbar/Navbar.css';
import sort from '../components/img/Rectangle 1.png'
import Posts from './Posts';
import Paginations from './Pagination';
import images1 from '../components/img/image 1.png';
import images3 from '../components/img/image 3.png';
import images4 from '../components/img/image 4.png';
import images5 from '../components/img/image 6.png';
import images6 from '../components/img/image 7.png';
import images7 from '../components/img/image 8.png';
import images8 from '../components/img/image 9.png';


function Shop() {
    const [posts, setPosts] = useState([]);
    const [currentPage, setCurrentPage] = useState(1);
    const [postsPerPage] = useState(10);
  
    useEffect(() => {
   
    let data = [
        { id: 1, rasm: images1, title: 'Syltherine', descrip: 'Stylish cafe chair', value: 'Rp 2.500.000' },
        { id: 2, rasm: images3, title: 'Lolito', descrip: 'Luxury big sofa', value: 'Rp 7000.000' },
        { id: 3, rasm: images4, title: 'Respira', descrip: 'Outdoor bar table and stool', value: 'Rp 500.000' },
        { id: 4, rasm: images5, title: 'Grifo', descrip: 'Night lamp', value: 'Rp 1.500.000' },
        { id: 5, rasm: images6, title: 'Muggo', descrip: 'Small mug', value: 'Rp 150.000' },
        { id: 6, rasm: images7, title: 'Pingky', descrip: 'Cute bed set', value: 'Rp 7.000.000' },
        { id: 7, rasm: images8, title: 'Potty', descrip: 'Minimalist flower pot', value: 'Rp 500.000' },
        { id: 8, rasm: images1, title: 'Leviossa', descrip: 'Stylish cave pots', value: 'Rp 2.500.000' },
      ]

      setPosts(data)
      
    
    }, []);
  
    // Get current posts
    const indexOfLastPost = currentPage * postsPerPage;
    const indexOfFirstPost = indexOfLastPost - postsPerPage;
    const currentPosts = posts.slice(indexOfFirstPost, indexOfLastPost);
  
    // Change page
    const paginate = pageNumber => setCurrentPage(pageNumber);
  
  return (
    <div>
<div className="shop">
        <img src={sort} alt="" className="shopimg" />
        <p className="shoptitle">Shop</p>
        <div className="sort">
            <div className="sort1">Showing 1-16 of 32 results</div>
        </div>
        <div className="paginationPart">

        <div>
      <Posts posts={currentPosts} />
      <Paginations
        postsPerPage={postsPerPage}
        totalPosts={posts.length}
        paginate={paginate}
      />
      

</div>
        </div>
    </div>
</div>
   
  )
} 

export default Shop