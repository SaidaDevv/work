import { Pagination } from '@mui/material';
import React from 'react';

const Paginations = ({ postsPerPage, totalPosts, paginate }) => {
  const pageNumbers = [];

  for (let i = 1; i <= Math.ceil(totalPosts / postsPerPage); i++) {
    pageNumbers.push(i);
  }

  return (
    <>
      <div className='pagination'>
        {pageNumbers.map(number => (
          <div key={number} className='page-item'>
            {/* <a onClick={() => paginate(number)} href='!#' className='page-link'>
              {number}
            </a> */}
            <Pagination onClick={() => paginate(number)}  count={4} variant="outlined"  > {number}</Pagination>
          </div>
        ))}
      </div>
    </>
  );
};

export default Paginations;
