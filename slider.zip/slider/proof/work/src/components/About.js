import React from 'react'

function About() {
  return (
    <div>hello</div>
  )
}

export default About