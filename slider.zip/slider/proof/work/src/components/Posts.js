import React from 'react';

const Posts = ({ posts }) => {
  

  return (
    <ul className='list-group mb-4'>
      {posts.map(post => (
        <div key={post.id} className='list-group-item'>
           {post.rasm}
          {post.title}
          {post.descrip}
        </div>
      ))}
    </ul>
  );
};

export default Posts;
